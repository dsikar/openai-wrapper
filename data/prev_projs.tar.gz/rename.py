import os
import re

def is_number(s):
    """Check if the first character of a string is a number."""
    return s[0].isdigit()

def pad_number(n):
    """Return a two-digit string, padding single digits with zero."""
    return str(n).zfill(2)

def rename_files(directory):
    # Filter files by extension and sort them
    file_extensions = ('.doc', '.docx', '.pdf')
    files = [f for f in os.listdir(directory) if f.endswith(file_extensions)]
    files.sort()

    # Rename files if their name does not start with a number
    for index, filename in enumerate(files, start=1):
        if not is_number(filename):
            # Generate new filename with prepended index
            new_filename = f"{pad_number(index)}-{filename}"
            old_path = os.path.join(directory, filename)
            new_path = os.path.join(directory, new_filename)
            
            # Rename file
            os.rename(old_path, new_path)
            print(f"Renamed '{filename}' to '{new_filename}'")
        else:
            print(f"Skipped '{filename}' (already starts with a number)")

# Specify your directory path here
your_directory_path = "."
rename_files(your_directory_path)

